package com.example.task1;

import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private EditText fahrenheitEditText, celsiusEditText;
    private Button convertButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fahrenheitEditText = findViewById(R.id.fahrenheit_edit_text);
        celsiusEditText = findViewById(R.id.celsius_edit_text);
        convertButton = findViewById(R.id.convert_button);

        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String fahrenheitText = fahrenheitEditText.getText().toString();
                if (fahrenheitText.isEmpty()) {
                    celsiusEditText.setText("");
                    return;
                }
                double fahrenheit = Double.parseDouble(fahrenheitText);
                double celsius = (fahrenheit - 32) * 5/9;
                celsiusEditText.setText(String.format("%.2f", celsius));
            }
        });
    }
}
